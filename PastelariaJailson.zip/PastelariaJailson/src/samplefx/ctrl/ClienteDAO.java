package samplefx.ctrl;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;
import pacote.TelaPrincipalController;

public class ClienteDAO {

	//TODO: Add
	//TODO: Update
	//TODO: Delete
	
	private static Connection connection;
	
	public ClienteDAO() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirCliente(ClienteVO C) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"Insert into Clientes values (?,?,?,?,?,?)" );
			
					preparedStatement.setInt(1, C.getId());
					preparedStatement.setString(2, C.getNome());
					preparedStatement.setString(3, C.getTelefone());
					preparedStatement.setString(4, C.getEndereco());
					preparedStatement.setInt(5, C.getNumero());
					preparedStatement.setString(6, C.getComplemento());

			preparedStatement.execute();
			
			 Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle( "Cliente Inserido");
		        alert.setHeaderText("Cliente Inserido com Sucesso!");
		        alert.setContentText("Cliente foi inserido na base de dados!");
		 
		        alert.showAndWait();			
		} catch (Exception e) {
			e.printStackTrace();
			
			Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
			dialogoErro.setTitle("ERRO");
			dialogoErro.setHeaderText("Erro no banco de dados, preencha novamente");
			//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
			dialogoErro.showAndWait();

		}
		
	}
	
	 public int ProxID() {
		 int prox = 0;
		 try {
		 ResultSet rs = connection.createStatement().executeQuery("Select top 1 id From Clientes order by id desc");
		 while (rs.next()) {
            	prox = rs.getInt(1);
            	return prox;
                
            }
		 }
		 catch(SQLException ex) {
	            System.err.println("Error"+ex);
	     }
		 return prox;
	 }
	
	public static void ConsultaCliente(ComboBox<Object> cb) throws SQLException { //mudar para consultarTudo
        try {
            
        	ObservableList<Object> Lista = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = connection.createStatement().executeQuery("SELECT * FROM Clientes;");
            while (rs.next()) {
                //get string from db,whichever way 
            	Lista.add(new String(rs.getString("nome")));
            }
            cb.setItems(null);
            cb.setItems(Lista);

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
	}
	/*
		public int ConsultaID (String nome) throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from Departamento where nome = '" + nome + "'");
			
			while (rs.next()) {
			      int id = rs.getInt(1);
			      return id;
			    }
			

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }*/
		//return ID;
	}
	
	
