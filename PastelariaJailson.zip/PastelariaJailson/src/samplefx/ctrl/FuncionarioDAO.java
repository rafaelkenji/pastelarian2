package samplefx.ctrl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert.AlertType;

public class FuncionarioDAO {

	//TODO: Add
	//TODO: Update
	//TODO: Delete
	
	private static Connection connection;
	
	public FuncionarioDAO() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirFuncionario(FuncionarioVO f) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"Insert into Funcionarios values (?,?,?,?,?)" );
			
					preparedStatement.setInt(1, f.getId());
					preparedStatement.setString(2, f.getNome());
					preparedStatement.setString(3, f.getSalario());
					preparedStatement.setString(4, f.getUsuario());
					preparedStatement.setString(5, f.getSenha());

					
					

			preparedStatement.execute();
			
			  Alert alert = new Alert(AlertType.INFORMATION);
		        alert.setTitle("Funcion�rio Inserido");
		        alert.setHeaderText("Funcion�rio Inserido com Sucesso!");
		        alert.setContentText("Funcion�rio foi inserido na base de dados!");
		 
		        alert.showAndWait();
			
		} catch (Exception e) {
			e.printStackTrace();
			Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
			dialogoErro.setTitle("ERRO");
			dialogoErro.setHeaderText("Erro no banco de dados, preencha novamente");
			//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
			dialogoErro.showAndWait();
		}
		
	}
	
	
	 public int ProxID() {
		 int prox = 0;
		 try {
		 ResultSet rs = connection.createStatement().executeQuery(" Select top 1 id From Funcionarios order by id desc");
		 while (rs.next()) {
            	prox = rs.getInt(1);
            	return prox;
                
            }
		 }
		 catch(SQLException ex) {
	            System.err.println("Error"+ex);
	     }
		 return prox;
	 }
	public boolean ConsultaLogin(String nome, String senha) {
		int ID = 0;
		boolean consulta = true;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from Funcionarios where usuario = '" + nome + "' and senha = '" +senha+"'");
			
			if (rs.next() == false) {
				/*Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
				dialogoErro.setTitle("ERRO");
				dialogoErro.setHeaderText("Usuario ou senha incorretos!!");
				//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
				dialogoErro.showAndWait();*/
				consulta = false;
				return consulta;
			}

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		//return ID;
		return consulta;
	}
}
