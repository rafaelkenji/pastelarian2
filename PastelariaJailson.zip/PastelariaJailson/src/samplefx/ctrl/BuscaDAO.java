package samplefx.ctrl;

import java.sql.Connection;

public class BuscaDAO {
	
	private static Connection connection;
	
	public BuscaDAO() {
			connection = DbUtil.getConnection();}
	

}
