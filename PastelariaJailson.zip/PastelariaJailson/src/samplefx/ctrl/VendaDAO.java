package samplefx.ctrl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;


public class VendaDAO {

	
		private static Connection connection;
		public VendaDAO() {
			connection = DbUtil.getConnection();
		}
		
		public void InserirVenda (VendaVO v) { //mudar para incluir
			
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"INSERT INTO Venda VALUES (?, ?, ?, ?)");
				
				
				preparedStatement.setInt(1,v.getId());
				preparedStatement.setString(2,v.getProduto());
				preparedStatement.setString(3, v.getPagamento());
				preparedStatement.setString(4, v.getMomentoPagamento());
				preparedStatement.execute();
				
				
				
				}
				
	
				
			
			catch (Exception e) {
				e.printStackTrace();
				Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
				dialogoErro.setTitle("ERRO");
				dialogoErro.setHeaderText("Venda n�o preenchido/a corretamente");
				//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
				dialogoErro.showAndWait();
			}
			
		}
		
		public static void ConsultaID(ComboBox<Object> cb) throws SQLException { //mudar para consultarTudo
	        try {
	            
	        	ObservableList<Object> Lista = FXCollections.observableArrayList();
	            // Execute query and store result in a resultset
	            ResultSet rs = connection.createStatement().executeQuery("Select distinct NumPedido From Venda");
	            while (rs.next()) {
	                //get string from db,whichever way 
	            	Lista.add((rs.getInt("NumPedido")));
	            }
	            cb.setItems(null);
	            cb.setItems(Lista);

	        } catch (SQLException ex) {
	            System.err.println("Error"+ex);
	        }
		}
		
		public int ConsultaPreco (String nome) throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT preco from Produtos where produto = '" + nome + "'");
			
			while (rs.next()) {
			      int preco = rs.getInt(1);
			      return preco;
			    }
			

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
		
		 public static void AddTable (TableView<BuscaVO> cb,int IdVenda,String produto, int qtd) throws SQLException {
				BuscaVO p = new BuscaVO();
				p.setIDVenda(IdVenda);
				p.setQtd(qtd);
				p.setProduto(produto);
		    	cb.getItems().add(p);
		    	
		    	
			}
		 
		 public int ProxID() {
			 int prox = 0;
			 try {
			 ResultSet rs = connection.createStatement().executeQuery(" Select top 1 NumPedido From Venda order by NumPedido desc");
			 while (rs.next()) {
	            	prox = rs.getInt(1);
	            	return prox;
	                
	            }
			 }
			 catch(SQLException ex) {
		            System.err.println("Error"+ex);
		     }
			 return prox;
		 }
		
		public static void ConsultaTudo(TableView<BuscaVO> cb, int id) throws SQLException { //mudar para consultarTudo
	        try {
	            
	        	//ObservableList<Object> Lista = FXCollections.observableArrayList();
	            // Execute query and store result in a resultset
	            ResultSet rs = connection.createStatement().executeQuery("Select produto, count(produto) as Quantidade from Venda where NumPedido = "+ id + " group by produto");
	            while (rs.next()) {
	            	AddTable(cb,id, rs.getString("produto"), rs.getInt("Quantidade"));
	                //get string from db,whichever way 
	            	//Lista.add(new String(rs.getString("nome")));
	            }
	           // cb.setItems(null);
	           // cb.setItems(Lista);

	        } catch (SQLException ex) {
	            System.err.println("Error"+ex);
	        }
		}
}
	
	
	

