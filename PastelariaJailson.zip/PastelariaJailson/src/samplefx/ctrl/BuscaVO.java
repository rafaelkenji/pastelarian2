package samplefx.ctrl;

public class BuscaVO {
	int IDVenda;
	String produto;
	int qtd;
	public int getIDVenda() {
		return IDVenda;
	}
	public void setIDVenda(int iDVenda) {
		IDVenda = iDVenda;
	}
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public int getQtd() {
		return qtd;
	}
	public void setQtd(int qtd) {
		this.qtd = qtd;
	}
	

}
