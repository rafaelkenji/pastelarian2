package pacote;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import pacote1.MomentoPag;
import pacote1.TipoPag;
import samplefx.ctrl.BuscaVO;
import samplefx.ctrl.ClienteDAO;
import samplefx.ctrl.ClienteVO;
import samplefx.ctrl.FuncionarioDAO;
import samplefx.ctrl.FuncionarioVO;
//import samplefx.ctrl.ProdAux;
//import samplefx.ctrl.ItemVenda;
//import samplefx.ctrl.ProdAux;
import samplefx.ctrl.ProdAuxVO;
//import samplefx.ctrl.ProdAux;
import samplefx.ctrl.ProdutoDAO;
import samplefx.ctrl.VendaDAO;
import samplefx.ctrl.VendaVO;
import javafx.scene.control.Alert;

import pacote.TextFieldFormatter;

public class TelaPrincipalController implements Initializable {
	
	ClienteDAO cdao = new ClienteDAO();
	FuncionarioDAO fdao = new FuncionarioDAO();
	ProdutoDAO pdao = new ProdutoDAO();
	VendaDAO vdao = new VendaDAO();
	
	

/**************************************** FXML **************************************************************/
	
	/************** PANE **********************/
    @FXML
    private Pane CadCliente;
    
    @FXML
    private Pane NovaVenda;
    
    @FXML
    private Pane CadFunc;
    
    @FXML
    private Pane Consulta;
    
    @FXML
    private Pane Login;
   /********************************************/
    
   /************** MENU ************************/     
    @FXML
    private Button btnCadCliente;
    
    @FXML   
    private Button btnConsulta;
    
    @FXML
    private Button btnVenda;
    
    @FXML
    private Button btnLogOut;

    @FXML
    private Label lbTitulo;
    
    @FXML
    private Button Func;
    
 
    /******************************************************/
    
    /**************** TELA LOGIN *****************************/
    @FXML
    private TextField txtLogin;
    
    @FXML
    private PasswordField txtSenha;
    
    @FXML
    private Button btnLogin;
    /**************************************************************/
    
    /*********** CAD FUNC ****************************************/
    @FXML
    private Button BtnSalvarFunc;
    
    @FXML
    private TextField txtIdFuncionario;
    
    @FXML
    private TextField TxtNomeFuncionario;
    
    @FXML
    private TextField TxtSalario;
    
    @FXML
    private TextField TxtLoginFunc;
    
    @FXML
    private TextField TxtSenhaFunc;
    
    /*************************************************************/
    
    /************* CONSULTA ************************************/
    @FXML
    private Button BtnBuscarPed;
    
    @FXML
    private TextField TxtNumPed;
    
    @FXML
    private ComboBox cbNumPed = new ComboBox();
    

    @FXML
    private TableView<BuscaVO> tableview2;
    /****************************************************************/
    
   
    /***************** CAD CLIENTE***********************************************/
    @FXML
    private TextField TxtNomeCliente;
    
    @FXML
    private TextField TxtNumero;
    
    @FXML
    private TextField TxtTelefone;
    
    @FXML
    private TextField TxtComplemento;
    
    @FXML
    private TextField TxtEndereco;
    
    @FXML
    private TextField txtId;
    
    @FXML
    private Button btnSalvarCliente;
    /**********************************************************************/
    
    /************** VENDA *****************************************/
    @FXML
    private Button BtnConfirmar;

    @FXML
    private ComboBox cbNome = new ComboBox();
    
    @FXML
    private Label lbPreco;
    
    @FXML
    private ComboBox 
    cbProduto = new ComboBox();
    
    @FXML
    private TableView<ProdAuxVO> tableView1;

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnRetirar;
    @FXML
    private TextField txtIDVenda;
    
    
    @FXML
    private ComboBox<MomentoPag> cbMomento;
    private List<MomentoPag> momento = new ArrayList<>();
    private ObservableList<MomentoPag> obsmomento;
    
    @FXML
    private ComboBox<TipoPag> cbTipoPag;
    private List<TipoPag> tipos = new ArrayList<>();
    private ObservableList<TipoPag> obsTipos;
    
    /**************************************************************/
    
/********************************** **** *******************************************************************/	    
    
/******************************** M�TODOS  X ***************************************************************/
    private void FDisable(Pane tela) { // Disable = false
    	tela.setDisable(false);
    }
    
    private void TDisable() { // Disable = true
    	Consulta.setDisable(true);
    	CadCliente.setDisable(true);
    	CadFunc.setDisable(true);
    	NovaVenda.setDisable(true);
    }
    
    private void TOpacity(Pane tela) { //Opacity = 1
    	tela.setOpacity(1);
    }
    
    private void FOpacity() { // Opacity = 0
    	NovaVenda.setOpacity(0);
    	CadFunc.setOpacity(0);
    	Consulta.setOpacity(0);
    	CadCliente.setOpacity(0);
    }
    
    private void showAlertWithHeaderText(String tipo) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle( tipo + " Inserido");
        alert.setHeaderText(tipo +" Inserido com Sucesso!");
        alert.setContentText(tipo +" foi inserido na base de dados!");
 
        alert.showAndWait();
    }
    
    private void alertaErro(String tipo) {
    	Alert dialogoErro = new Alert(Alert.AlertType.ERROR);
		dialogoErro.setTitle("ERRO");
		dialogoErro.setHeaderText(tipo +" n�o preenchido/a corretamente");
		//dialogoErro.setContentText("UM ERROR!!! UM ERRO ACONTECEU!!");
		dialogoErro.showAndWait();
    }
    
    public void LimpaCampos() {
    	TxtNomeCliente.clear();
    	TxtNumero.clear();
    	TxtTelefone.clear();
    	TxtComplemento.clear();
    	TxtEndereco.clear();
    	txtId.clear();
    	txtLogin.clear();
		txtSenha.clear();
		txtIdFuncionario.clear();
	    TxtNomeFuncionario.clear();
	    TxtSalario.clear();
	    TxtLoginFunc.clear();
	    TxtSenhaFunc.clear();
	    txtIDVenda.clear();
	    cbNome.setValue(null);;
	    cbProduto.setValue(null);
	    cbMomento.setValue(null);
	    cbTipoPag.setValue(null);
	    tableView1.getItems().clear();
	    tableview2.getItems().clear();
	    TxtNumPed.clear();
	    preco = 0;
	    lbPreco.setText("");
	    contador = 0;
	    
    }
    
    
    public void VoltaInic() {
    	TDisable();
    	FOpacity();
    	btnCadCliente.setVisible(false);
    	btnConsulta.setVisible(false);
    	btnVenda.setVisible(false);
    	Func.setVisible(false);
    	btnLogOut.setVisible(false);
    	lbTitulo.setText("PASTELARIA DO JAILSON");
    	btnCadCliente.setVisible(true);
		btnLogOut.setVisible(true);
		btnConsulta.setVisible(true);
		btnVenda.setVisible(true);
		Func.setVisible(true);
    }
    
/******************************** ********** ***************************************************************/
    
/********************************* COMBO  BOX **************************************************************/
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		TableColumn colunaNome = new TableColumn("Produto");
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

		
		TableColumn colunaProduto = new TableColumn("Produto");
		colunaProduto.setCellValueFactory(new PropertyValueFactory<>("produto"));
		
		TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("qtd"));
		
		/*TableColumn colunaID = new TableColumn("ID");
		colunaID.setCellValueFactory(new PropertyValueFactory<>("IDVenda"));
		*/
		
		tableview2.getColumns().clear();
		tableview2.getColumns().addAll(colunaProduto, colunaQuantidade);
		colunaProduto.setPrefWidth(200);
		
		
		/*TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));*/
		
		tableView1.getColumns().clear();
		tableView1.getColumns().addAll(colunaNome);
		colunaNome.setPrefWidth(202);
		
		carregarMomento();
		carregarTipos();
		
		try {
			pdao.ConsultaProduto(cbProduto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    
    public void carregarMomento() {
		
		MomentoPag momento1 = new MomentoPag(1,"Em casa");
		MomentoPag momento2 = new MomentoPag(2,"No estabelecimento");
		
		momento.add(momento1);
		momento.add(momento2);
		
		obsmomento = FXCollections.observableArrayList(momento);
		
		cbMomento.setItems(obsmomento);
		
	}
    
    public void carregarTipos() {
		
		TipoPag tipo1 = new TipoPag(1,"Dinheiro");
		TipoPag tipo2 = new TipoPag(2,"Cart�o de Cr�dito");
		TipoPag tipo3 = new TipoPag(3,"Cart�o de D�bito");
		
		
		tipos.add(tipo1);
		tipos.add(tipo2);
		tipos.add(tipo3);
		
		
		obsTipos = FXCollections.observableArrayList(tipos);
		
		cbTipoPag.setItems(obsTipos);
		
	}
   
    /********************************* ********** **************************************************************/
    
    /************************************** M�SCARA ************************************************************/
    @FXML
    void TxtLoginKeyReleased() {//M�SCARA NO TXTLOGIN
		TextFieldFormatter tff = new TextFieldFormatter();
		tff.setMask("????????");
		tff.setCaracteresValidos("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		tff.setTf(txtLogin);
		tff.formatter();
    }
    
    @FXML
    void txtIdkeyReleased() {
    	/*TextFieldFormatter tff = new TextFieldFormatter();
		tff.setMask("###");
		tff.setCaracteresValidos("1234567890");
		tff.setTf(txtId);
		tff.formatter();*/

    }
    @FXML
    void TxtNumerokeyreleased() {
    	/*TextFieldFormatter tff = new TextFieldFormatter();
		tff.setMask("####");
		tff.setCaracteresValidos("1234567890");
		tff.setTf(TxtNumero);
		tff.formatter();*/

    }
    @FXML
    void TxtTelefonekeyreleased() {
    	TextFieldFormatter tff = new TextFieldFormatter();
		tff.setMask("#####-####");
		tff.setCaracteresValidos("1234567890");
		tff.setTf(TxtTelefone);
		tff.formatter();

    }
    @FXML
    void txtIdFuncionarioKeyReleased() {
    	/*TextFieldFormatter tff = new TextFieldFormatter();
		//tff.setMask("###");
		tff.setCaracteresValidos("1234567890");
		tff.setTf(txtIdFuncionario);
		tff.formatter();*/
    }
    
    @FXML
    void TxtSalarioKeyReleased() {
    	TextFieldFormatter tff = new TextFieldFormatter();
		tff.setMask("####");
		tff.setCaracteresValidos("1234567890");
		tff.setTf(TxtSalario);
		tff.formatter();
    }
    @FXML
    void TxtLoginFuncKeyReleased() {
    	TextFieldFormatter tff = new TextFieldFormatter();
    	tff.setMask("????????");
		tff.setCaracteresValidos("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		tff.setTf(TxtLoginFunc);
		tff.formatter();
    }

   
    /************************************** ******* ************************************************************/
    
    /********************************* TELA DE LOGIN ***********************************************************/
    @FXML
    void FazerLogin(ActionEvent event) {
    	FuncionarioDAO F = new FuncionarioDAO();
    
    		if(txtLogin.getText()==null || txtLogin.getText().trim().equals("")){
    		  
    			alertaErro("Login");
    			
    		}
    		else if(txtSenha.getText()==null || txtSenha.getText().trim().equals("")){
    			alertaErro("Senha");
    		}
    		else if(F.ConsultaLogin(txtLogin.getText(), txtSenha.getText()) == false){
    			alertaErro("Campo");
    		}
    		else {
    			Login.setDisable(true);
    			Login.setOpacity(0);
    			btnCadCliente.setVisible(true);
    			btnLogOut.setVisible(true);
    			btnConsulta.setVisible(true);
    			btnVenda.setVisible(true);
    			Func.setVisible(true);
    			LimpaCampos();	
    		}
    }
    
   
    
    /********************************* ************* ***********************************************************/
    
    /********************************* NOVA VENDA **************************************************************/
    int contador = 0;
    
    
    public void AddTable () throws SQLException {
		ProdAuxVO p = new ProdAuxVO();
		p.setNome(cbProduto.getValue().toString());
		p.setQtd(1);
    	tableView1.getItems().add(p);
    	
    	
	}
	
	public void DeleteTable () throws SQLException {
		
		ObservableList<ProdAuxVO> selecionado, todos; 
		todos = tableView1.getItems();
		selecionado = tableView1.getSelectionModel().getSelectedItems();
		
		
		for(ProdAuxVO aux: selecionado){
			preco -= (vdao.ConsultaPreco(aux.getNome()));
			}
		System.out.println(preco);
		
		selecionado.forEach(todos::remove);
		
	}
    
    @FXML
    void Retirar(ActionEvent event) {
    	try {
			DeleteTable ();
			contador--;
			lbPreco.setText("PRE�O TOTAL: R$ "+ preco + ",00");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    int preco = 0;
    @FXML
    void Add(ActionEvent event) {
    	try {
			AddTable();
			preco += vdao.ConsultaPreco(cbProduto.getValue().toString());
			contador++;
			lbPreco.setText("PRE�O TOTAL: R$ "+ preco + ",00");
			//System.out.println(preco);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    @FXML
    void Confirmar(ActionEvent event) {
    	int cont = 0;

    	if(txtIDVenda.getText()==null || txtIDVenda.getText().trim().equals("")){
  		  
			alertaErro("ID");
			
		}
		else if(cbNome.getValue()==null){
			alertaErro("Nome");
		}
		else if(cbMomento.getValue()==null){
			alertaErro("Momento");
		}
		else if(cbTipoPag.getValue()==null){
			alertaErro("Tipo de pagamento");
		}
		else if(contador<= 0) {
			alertaErro("Produtos");
		}
		else {
    	
    	
    	 for (ProdAuxVO row : tableView1.getItems()) {
 	    	 cont++;
 	    	VendaVO v = new VendaVO();
 	    	String nome = row.getNome();
 	    	
 	    	v.setMomentoPagamento(cbMomento.getValue().toString());
 	    	v.setPagamento(cbTipoPag.getValue().toString());
 	    	v.setId(Integer.parseInt(txtIDVenda.getText()));
 	    	v.setProduto(nome);
 	    	//v.setIdProduto(pdao.ConsultaID(nome));
 	    	//v.setIdVenda(vdao.ResgataMaiorID());
 	    	//v.setQuantidade(row.getQuantidade());
 	    	
 	    	vdao.InserirVenda(v);
 	    	
 	    	if (cont ==1) {
 	    	 Alert alert = new Alert(AlertType.INFORMATION);
 	        alert.setTitle( "Venda Inserido");
 	        alert.setHeaderText("Venda Inserida com Sucesso!" + "\n" + "Pre�o:R$ " + preco + ",00");
 	        alert.setContentText("Venda foi inserida na base de dados!");
 	 
 	        alert.showAndWait();
 	        VoltaInic();
 	    	//showAlertWithHeaderText()
 	    	}
 	    }
    	

    	 	LimpaCampos();
    	 	//txtIDVenda.setText(Integer.toString(idVenda));
    	 	//FDisable(Login);
        	
		}
    }

    /********************************* ********** **************************************************************/
    
    /********************************* CAD CLIENTE *************************************************************/
    @FXML
    void SalvarCliente(ActionEvent event) {
    	
    	if(txtId.getText()==null ||txtId.getText().trim().equals("")){
  		  
    		alertaErro("ID");
		}
    	else if(TxtNomeCliente.getText()==null || TxtNomeCliente.getText().trim().equals("")){
    		alertaErro("Nome");
			
		}
    	else if(TxtTelefone.getText()==null || TxtTelefone.getText().trim().equals("")){
    		alertaErro("Telefone");
			
		}
    	else if(TxtEndereco.getText()==null || TxtEndereco.getText().trim().equals("")){
    		alertaErro("Endere�o");
			
		}
    	else if(TxtNumero.getText()==null || TxtNumero.getText().trim().equals("")){
    		alertaErro("N�mero");
			
		}
    	else if(TxtComplemento.getText()==null || TxtComplemento.getText().trim().equals("")){
    		alertaErro("Complemento");
			
		}
    	//else if((txtId.getText()) ||txtId.getText().trim().equals("")){
    		//alertaErro("Complemento");
			
		//}
    	else {
    	ClienteVO c = new ClienteVO();
    	c.setId(Integer.parseInt(txtId.getText()));
    	c.setNome(TxtNomeCliente.getText());
    	c.setTelefone(TxtTelefone.getText());
    	c.setEndereco(TxtEndereco.getText());
    	c.setNumero(Integer.parseInt(TxtNumero.getText()));
    	c.setComplemento(TxtComplemento.getText());
    	
    	cdao.InserirCliente(c);
    	//showAlertWithHeaderText("Cliente");
    	LimpaCampos();
    	VoltaInic();
    	
    	}
    }
    
    /********************************* *********** *************************************************************/
    
    /********************************* MENU ********************************************************************/
    @FXML
    void LogOut(ActionEvent event) {
    	FDisable(Login);
    	TDisable();
    	FOpacity();
    	TOpacity(Login);
    	btnCadCliente.setVisible(false);
    	btnConsulta.setVisible(false);
    	btnVenda.setVisible(false);
    	Func.setVisible(false);
    	btnLogOut.setVisible(false);
    	lbTitulo.setText("PASTELARIA DO JAILSON");
    	txtLogin.requestFocus();
    }
     
    @FXML
    void Venda(ActionEvent event) {//M�todo acontece quando clica no bot�o nova venda
    	
    	//LimpaCampos();
    	int idVenda;
    	idVenda = vdao.ProxID() + 1;
    	txtIDVenda.setText(Integer.toString(idVenda));
    	TDisable();
    	try {
			cdao.ConsultaCliente(cbNome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	FDisable(NovaVenda);
    	FOpacity();
    	TOpacity(NovaVenda);
    	lbTitulo.setText("NOVA VENDA");
    	
    }
    
    @FXML
    void Consultar(ActionEvent event) {//M�todo acontece quando clica no bot�o Consultar
    	
    	TDisable();
    	FDisable(Consulta);
    	FOpacity();
    	try {
			vdao.ConsultaID(cbNumPed);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	TOpacity(Consulta);
    	lbTitulo.setText("CONSULTA DE PEDIDO");
    	LimpaCampos();
    }
    
    @FXML
    void Cadastrar(ActionEvent event) { //M�todo acontece quando clica no bot�o cadastrar cliente
    	int idCli = cdao.ProxID() + 1;
    	txtId.setText(Integer.toString(idCli));
    	TDisable();
    	
    	FDisable(CadCliente);
    	FOpacity();
    	TOpacity(CadCliente);
    	lbTitulo.setText("CADASTRO DE CLIENTE");
    	txtId.requestFocus();
    }
    
    @FXML
    void CadFuncs(ActionEvent event) {//M�todo acontece quando clica no bot�o cadastrar funcion�rio
    	int idfunc = fdao.ProxID() + 1;
    	txtIdFuncionario.setText(Integer.toString(idfunc));
    	TDisable();
    	FDisable(CadFunc);
    	FOpacity();
    	TOpacity(CadFunc);
    	lbTitulo.setText("CADASTRO DE FUNCION�RIO");
    	txtIdFuncionario.requestFocus();
    }
    
    /********************************* CONSULTAR ********************************************************************/
    public void AddTable1 () throws SQLException {
		/*BuscaVO p = new BuscaVO();
		p.setNome(cbProdutos.getValue().toString());
		p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
		tbItens.getItems().add(p);
		cbProdutos.setValue("");
		cbProdutos.requestFocus();
		txtQuantidade.setText("");
		*/
		//valor_total += (pdao.ConsultaPreco(p.getNome()) * p.getQuantidade());
		//lblValor.setText( String.valueOf(valor_total));
	}

    @FXML
    void Buscar(ActionEvent event) {
    	if(cbNumPed.getValue() == null) {
    		alertaErro("ComboBox");
    	}
    	else {
    	
    	tableview2.getItems().clear();
    	VendaDAO venda = new VendaDAO();
    	try {
			venda.ConsultaTudo(tableview2, Integer.parseInt(cbNumPed.getValue().toString()));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    }
    
    @FXML
    void BuscarPed(ActionEvent event) {
    	try {
			AddTable1();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }

   
 
    /************************ CAD FUNC ************************************************************************/
    @FXML
    void SalvarFunc(ActionEvent event) {
    	
    	if(txtIdFuncionario.getText()==null ||txtIdFuncionario.getText().trim().equals("")){
    		alertaErro("ID");
		}
    	else if(TxtNomeFuncionario.getText()==null || TxtNomeFuncionario.getText().trim().equals("")){
    		alertaErro("Nome");
		}
    	else if(TxtSalario.getText()==null || TxtSalario.getText().trim().equals("")){
    		alertaErro("Sal�rio");
		}
    	else if(TxtLoginFunc.getText()==null || TxtLoginFunc.getText().trim().equals("")){
    		alertaErro("Login");
		}
    	else if(TxtSenhaFunc.getText()==null || TxtSenhaFunc.getText().trim().equals("")){
    		alertaErro("Senha");
		}
    	else {
    	FuncionarioVO f = new FuncionarioVO();
    	f.setId(Integer.parseInt(txtIdFuncionario.getText()));
    	f.setNome(TxtNomeFuncionario.getText());
    	f.setSalario(TxtSalario.getText());
    	f.setUsuario(TxtLoginFunc.getText());
    	f.setSenha(TxtSenhaFunc.getText());
    	
    	fdao.InserirFuncionario(f);
    	//showAlertWithHeaderText("Funcion�rio");
    	LimpaCampos();
    	VoltaInic();
    	}
    }
    /*******************************************************************************************************/
}
